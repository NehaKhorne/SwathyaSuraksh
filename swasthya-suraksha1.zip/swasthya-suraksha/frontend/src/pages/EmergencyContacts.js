import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import "./Contacts.css";
import WhatsAppQR from "../assets/whatsapp-qr.png";

export default function EmergencyContacts() {
  const navigate = useNavigate();

  const [contacts, setContacts] = useState([]);
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [showQR, setShowQR] = useState(false);

  useEffect(() => {
    const saved = JSON.parse(localStorage.getItem("contacts")) || [];
    setContacts(saved);
  }, []);

  const saveContacts = (updated) => {
    setContacts(updated);
    localStorage.setItem("contacts", JSON.stringify(updated));
  };

  const addContact = () => {
    if (!name || !phone) {
      alert("Please fill all fields");
      return;
    }

    const newContact = {
      id: Date.now(),
      name,
      phone,
    };

    saveContacts([...contacts, newContact]);
    setName("");
    setPhone("");
  };

  const deleteContact = (id) => {
    const updated = contacts.filter((c) => c.id !== id);
    saveContacts(updated);
  };

  return (
    <div className="contacts-page">
      <h2>Emergency Contacts</h2>

      <button className="back-btn" onClick={() => navigate("/dashboard")}>
        ← Back to Dashboard
      </button>

      {/* WhatsApp QR Section */}
      <div className="whatsapp-section">
        <button className="whatsapp-btn" onClick={() => setShowQR(!showQR)}>
          📲 Enable WhatsApp SOS
        </button>

        {showQR && (
          <div className="qr-box">
            <p>Scan this QR on your mobile to connect WhatsApp</p>
            <img src={WhatsAppQR} alt="WhatsApp QR Code" />
            <p className="note">
              Open WhatsApp → Scan QR → Send <b>join</b> message
            </p>
          </div>
        )}
      </div>

      <div className="add-contact">
        <input
          placeholder="Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
        <input
          placeholder="Phone Number"
          value={phone}
          onChange={(e) => setPhone(e.target.value)}
        />
        <button onClick={addContact}>Add Contact</button>
      </div>

      <div className="contacts-list">
        {contacts.length === 0 && <p>No contacts added yet.</p>}

        {contacts.map((c) => (
          <div className="contact-card" key={c.id}>
            <div>
              <strong>{c.name}</strong>
              <p>{c.phone}</p>
            </div>
            <button onClick={() => deleteContact(c.id)}>Delete</button>
          </div>
        ))}
      </div>
    </div>
  );
}
