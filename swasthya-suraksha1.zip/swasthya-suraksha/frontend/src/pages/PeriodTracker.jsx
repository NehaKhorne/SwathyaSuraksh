import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import "./PeriodTracker.css";

export default function PeriodTracker() {
  const navigate = useNavigate();

  const [lastPeriod, setLastPeriod] = useState("");
  const [cycleLength, setCycleLength] = useState(28);
  const [periodLength, setPeriodLength] = useState(5);
  const [cycleData, setCycleData] = useState(null);
  const [history, setHistory] = useState([]);
  const [symptoms, setSymptoms] = useState([]);
  const [privacyMode, setPrivacyMode] = useState(false);
  const [lang, setLang] = useState("en");

  const labels = {
    en: { next: "Next Period" },
    hi: { next: "अगली माहवारी" },
  };

  const [viewDate, setViewDate] = useState(new Date());
  const today = new Date();

  // Core function to build the cycle model
  const buildCycleModel = (lastPeriod, cycleLength, periodLength) => {
    const start = new Date(lastPeriod);

    const periodRange = [];
    for (let i = 0; i < periodLength; i++) {
      const d = new Date(start);
      d.setDate(start.getDate() + i);
      periodRange.push(d.toDateString());
    }

    const ovulationDate = new Date(start);
    ovulationDate.setDate(start.getDate() + cycleLength - 14);

    const fertileWindow = [];
    for (let i = -5; i <= 1; i++) {
      const d = new Date(ovulationDate);
      d.setDate(ovulationDate.getDate() + i);
      fertileWindow.push(d.toDateString());
    }

    const nextPeriodDate = new Date(start);
    nextPeriodDate.setDate(start.getDate() + cycleLength);

    return {
      periodRange,
      fertileWindow,
      ovulationDate: ovulationDate.toDateString(),
      nextPeriodDate: nextPeriodDate.toDateString(),
    };
  };

  // Function to determine the daily state of the cycle
  const getDailyCycleState = (todayStr, model) => {
    if (model.periodRange.includes(todayStr)) {
      return { phase: "Menstrual", fertility: "None" };
    }

    if (model.ovulationDate === todayStr) {
      return { phase: "Ovulation", fertility: "Peak" };
    }

    if (model.fertileWindow.includes(todayStr)) {
      return { phase: "Fertile", fertility: "High" };
    }

    return { phase: "Luteal", fertility: "Low" };
  };

  // Function to analyze health risks based on cycle parameters
  const analyzeHealthRisk = ({ cycleLength, periodLength }) => {
    const risks = [];

    if (cycleLength > 35)
      risks.push({
        level: "High",
        reason: "Cycle length >35 days suggests irregular ovulation",
      });

    if (cycleLength < 21)
      risks.push({
        level: "Medium",
        reason: "Short cycles may indicate hormonal imbalance",
      });

    if (periodLength > 7)
      risks.push({
        level: "Medium",
        reason: "Prolonged bleeding detected",
      });

    if (risks.length === 0) {
      risks.push({
        level: "Low",
        reason: "Cycle parameters fall within healthy ranges",
      });
    }

    return risks;
  };

  // Function to calculate confidence score
  const calculateConfidenceScore = (cycleLength, periodLength) => {
    let score = 100;

    if (cycleLength < 26 || cycleLength > 32) score -= 20;
    if (periodLength < 3 || periodLength > 7) score -= 10;

    return Math.max(score, 40);
  };

  // Function to calculate time to next period
  const getTimeToNextPeriod = (nextPeriodDate) => {
    const today = new Date();
    const next = new Date(nextPeriodDate);

    return Math.ceil((next - today) / (1000 * 60 * 60 * 24));
  };

  // Utility function to calculate cycle data
  const calculateCycleData = ({ lastPeriod, cycleLength, periodLength }) => {
    const start = new Date(lastPeriod);

    const periodDays = Array.from({ length: periodLength }, (_, i) => {
      const d = new Date(start);
      d.setDate(start.getDate() + i);
      return d.toDateString();
    });

    const ovulation = new Date(start);
    ovulation.setDate(start.getDate() + cycleLength - 14);

    const fertileDays = Array.from({ length: 7 }, (_, i) => {
      const d = new Date(ovulation);
      d.setDate(ovulation.getDate() - 5 + i);
      return d.toDateString();
    });

    const nextPeriod = new Date(start);
    nextPeriod.setDate(start.getDate() + cycleLength);

    return {
      periodDays,
      fertileDays,
      ovulation: ovulation.toDateString(),
      nextPeriod: nextPeriod.toDateString(),
    };
  };

  // Utility function to determine the current phase
  const getCyclePhase = (todayStr, cycleData) => {
    if (!cycleData) return null;

    if (cycleData.periodDays.includes(todayStr)) return "Menstrual";
    if (cycleData.ovulation === todayStr) return "Ovulation";
    if (cycleData.fertileDays.includes(todayStr)) return "Fertile";
    return "Luteal";
  };

  // Utility function to generate health insights
  const getHealthInsights = ({ cycleLength, periodLength }) => {
    const insights = [];

    if (cycleLength > 35)
      insights.push("Irregular cycle detected (possible hormonal imbalance).\n");

    if (periodLength > 7)
      insights.push("Prolonged menstruation detected.\n");

    if (cycleLength < 21)
      insights.push("Short cycle detected.\n");

    if (insights.length === 0)
      insights.push("Your cycle appears within a healthy range.\n");

    return insights;
  };

  // Utility function to calculate confidence score
  const getCycleConfidenceScore = (cycleLength) => {
    if (cycleLength >= 26 && cycleLength <= 32) return 90;
    if (cycleLength >= 23 && cycleLength <= 35) return 70;
    return 40;
  };

  // Utility function to generate notifications
  const getNotifications = (cycleData) => {
    if (!cycleData) return null;

    const today = new Date();
    const next = new Date(cycleData.nextPeriod);

    const daysLeft = Math.ceil(
      (next - today) / (1000 * 60 * 60 * 24)
    );

    if (daysLeft === 3)
      return "Your period is expected in 3 days.";

    if (daysLeft === 0)
      return "Your period is expected today.";

    return null;
  };

  // Utility function to validate user input
  const validateInput = (lastPeriod, cycleLength, periodLength) => {
    if (!lastPeriod) return "Last period date required.";
    if (periodLength > cycleLength)
      return "Period duration cannot exceed cycle length.";
    return null;
  };

  // Function to determine the type of day for the calendar
  const getDayType = (dayStr, cycleModel) => {
    if (cycleModel.periodRange.includes(dayStr)) return "period";
    if (cycleModel.ovulationDate === dayStr) return "ovulation";
    if (cycleModel.fertileWindow.includes(dayStr)) return "fertile";
    return "normal";
  };

  // Function to predict the next period date
  const predictNextPeriod = (lastPeriod, cycleLength) => {
    const d = new Date(lastPeriod);
    d.setDate(d.getDate() + cycleLength);
    return d.toDateString();
  };

  // Function to generate symptom insights
  const generateSymptomInsights = (symptoms, phase) => {
    const insights = [];

    if (symptoms.cramps >= 2 && phase === "Menstrual") {
      insights.push({
        reason: "Uterine muscle contractions due to prostaglandins.",
        remedy: "Heat pad, light stretching, magnesium-rich food.",
      });
    }

    if (symptoms.mood >= 2 && phase === "Luteal") {
      insights.push({
        reason: "Hormonal fluctuation affecting neurotransmitters.",
        remedy: "Adequate sleep, breathing exercises, reduce caffeine.",
      });
    }

    if (symptoms.fatigue >= 2 && phase === "Menstrual") {
      insights.push({
        reason: "Blood loss causing reduced oxygen transport.",
        remedy: "Iron-rich foods, hydration, rest.",
      });
    }

    if (symptoms.bloating >= 2 && phase === "Luteal") {
      insights.push({
        reason: "Hormonal water retention.",
        remedy: "Low-salt diet, light walking.",
      });
    }

    if (symptoms.acne >= 2) {
      insights.push({
        reason: "Hormonal stimulation of oil glands.",
        remedy: "Hydration, avoid sugar & oily foods.",
      });
    }

    return insights;
  };

  const calculateCycle = () => {
    const validationError = validateInput(lastPeriod, cycleLength, periodLength);
    if (validationError) return alert(validationError);

    const data = calculateCycleData({ lastPeriod, cycleLength, periodLength });
    setCycleData(data);
  };

  const saveCycleToHistory = () => {
    setHistory([...history, { cycleLength, periodLength, date: new Date() }]);
  };

  const getMonthDays = () => {
    const year = viewDate.getFullYear();
    const month = viewDate.getMonth();
    const firstDay = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();

    const blanks = Array(firstDay === 0 ? 6 : firstDay - 1).fill(null);
    const days = Array.from({ length: daysInMonth }, (_, i) =>
      new Date(year, month, i + 1)
    );

    return [...blanks, ...days];
  };

  const notifyUpcomingPeriod = (nextPeriodDate) => {
    const today = new Date();
    const daysLeft = Math.ceil(
      (new Date(nextPeriodDate) - today) / (1000 * 60 * 60 * 24)
    );
    if (daysLeft <= 3) {
      alert(`Your next period is in ${daysLeft} days.`);
    }
  };

  const getCycleRisk = () => {
    if (cycleLength > 35) return "High risk of irregular cycle";
    if (cycleLength < 21) return "Short cycle detected";
    return "Cycle length looks normal";
  };

  const getCurrentPhase = () => {
    const todayStr = today.toDateString();
    if (cycleData?.periodDays?.includes(todayStr)) return "Menstrual";
    if (cycleData?.ovulation === todayStr) return "Ovulation";
    if (cycleData?.fertileDays?.includes(todayStr)) return "Fertile";
    return "Luteal";
  };

  const getReminderMessage = () => {
    if (!cycleData) return null;
    if (cycleData?.ovulation === today.toDateString())
      return "🌸 Today is your ovulation day.";
    return null;
  };

  const moodByPhase = {
    Menstrual: "Low energy, emotional sensitivity",
    Ovulation: "Confident, social, high focus",
    Luteal: "Irritable, low motivation",
  };

  const getCycleScore = () => {
    if (cycleLength >= 26 && cycleLength <= 32) return 90;
    if (cycleLength >= 23 && cycleLength <= 35) return 70;
    return 40;
  };

  // Function to generate insights based on symptoms and daily state
  const generateInsights = (dailyState, symptoms) => {
    const insights = [];

    if (symptoms.cramps >= 3 && dailyState.phase !== "Menstrual") {
      insights.push("Severe cramps outside period may require medical attention.");
    }

    if (symptoms.headache >= 2 && dailyState.phase === "Ovulation") {
      insights.push("Hormonal headache detected during ovulation.");
    }

    if (symptoms.moodSwings >= 3 && dailyState.phase === "Luteal") {
      insights.push("Possible PMS-related mood changes.");
    }

    if (symptoms.fatigue >= 3 && dailyState.phase !== "Menstrual") {
      insights.push("Fatigue outside menstruation may indicate deficiency.");
    }

    if (symptoms.bloating >= 3 && dailyState.phase === "Luteal") {
      insights.push("Hormonal bloating detected.");
    }

    if (symptoms.acne >= 3 && dailyState.phase === "Ovulation") {
      insights.push("Hormonal acne pattern observed.");
    }

    // Example of combining symptoms for a broader insight
    if (
      symptoms.moodSwings >= 3 &&
      symptoms.cramps >= 2 &&
      dailyState.phase === "Luteal"
    ) {
      insights.push("Symptoms suggest moderate PMS.");
    }

    return insights;
  };

  // Recommendations based on symptoms
  const recommendations = {
    cramps: "Warm compress & light stretching",
    fatigue: "Iron-rich diet & hydration",
    moodSwings: "Mindfulness & sleep hygiene",
    headache: "Hydration & rest",
    bloating: "Low-sodium foods & herbal teas",
    acne: "Reduce sugar & hydrate",
  };

  useEffect(() => {
    if (cycleData?.nextPeriod) {
      notifyUpcomingPeriod(cycleData.nextPeriod);
    }
  }, [cycleData]);

  return (
    <div className="period-page">
      <button className="back-btn" onClick={() => navigate("/health")}>
        ← Back
      </button>

      <h2>Period Tracker</h2>

      {/* INPUT */}
      <div className="input-card">
        <label>Last period start date</label>
        <input
          type="date"
          value={lastPeriod}
          onChange={(e) => setLastPeriod(e.target.value)}
        />

        <label>Cycle length (days)</label>
        <input
          type="number"
          value={cycleLength}
          onChange={(e) => setCycleLength(+e.target.value)}
        />

        <label>Period duration (days)</label>
        <input
          type="number"
          value={periodLength}
          onChange={(e) => setPeriodLength(+e.target.value)}
        />

        <button onClick={calculateCycle}>Save Cycle</button>
      </div>

      {/* CALENDAR */}
      {cycleData && (
        <div className="calendar">
          <div className="calendar-header">
            <button
              onClick={() =>
                setViewDate(
                  new Date(viewDate.getFullYear(), viewDate.getMonth() - 1, 1)
                )
              }
            >
              ‹
            </button>

            <h3>
              {viewDate.toLocaleString("default", { month: "long" })}{" "}
              {viewDate.getFullYear()}
            </h3>

            <button
              onClick={() =>
                setViewDate(
                  new Date(viewDate.getFullYear(), viewDate.getMonth() + 1, 1)
                )
              }
            >
              ›
            </button>
          </div>

          <div className="weekdays">
            {["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].map((d) => (
              <span key={d}>{d}</span>
            ))}
          </div>

          <div className="calendar-grid">
            {getMonthDays().map((day, i) => {
              if (!day) return <div key={i} />;

              const dayStr = day.toDateString();
              let cls = "day";

              if (cycleData?.periodDays?.includes(dayStr)) cls += " period";
              else if (cycleData?.fertileDays?.includes(dayStr))
                cls += " fertile";
              else if (cycleData?.ovulation === dayStr)
                cls += " ovulation";

              if (dayStr === today.toDateString()) cls += " today";

              return (
                <div key={i} className={cls}>
                  {day.getDate()}
                </div>
              );
            })}
          </div>

          {/* LEGEND */}
          <div className="legend">
            <span className="l period">Period</span>
            <span className="l fertile">Fertile</span>
            <span className="l ovulation">Ovulation</span>
          </div>
        </div>
      )}

      <div className="info-card">
        <label>
          <input type="checkbox" onChange={() => setPrivacyMode(!privacyMode)} />
          Privacy Mode
        </label>

        {!privacyMode && (
          <p>
            🩸 {labels[lang].next}: {cycleData?.nextPeriod || "--"}
          </p>
        )}

        <p>
          🌸 <strong>Ovulation day:</strong> {cycleData?.ovulation || "--"}
        </p>
      </div>

      {cycleData && (
        <p className="risk">
          ⚠️ <strong>Cycle Insight:</strong> {getCycleRisk()}
        </p>
      )}

      {cycleData && (
        <div className="phase-card">
          <h4>🌿 Current Phase: {getCurrentPhase()}</h4>
          <p>
            {getCurrentPhase() === "Menstrual" &&
              "Rest, warm foods, avoid heavy workouts."}
            {getCurrentPhase() === "Ovulation" &&
              "High energy phase – best for workouts."}
            {getCurrentPhase() === "Luteal" &&
              "Reduce caffeine, focus on sleep."}
          </p>
        </div>
      )}

      {getReminderMessage() && (
        <div className="notification">{getReminderMessage()}</div>
      )}

      <p className="mood">
        🧠 <strong>Mental Health Insight:</strong> {moodByPhase[getCurrentPhase()]}
      </p>

      {/* SYMPTOM TRACKER */}
      <div className="symptom-card">
        <h4>📝 Symptoms Today</h4>
        {[
          "Cramps",
          "Headache",
          "Mood swings",
          "Acne",
          "Bloating",
        ].map((s) => (
          <label key={s}>
            <input
              type="checkbox"
              onChange={(e) =>
                e.target.checked
                  ? setSymptoms([...symptoms, s])
                  : setSymptoms(symptoms.filter((x) => x !== s))
              }
            />
            {s}
          </label>
        ))}
      </div>

      {symptoms.length > 2 && (
        <p className="insight">
          ⚠️ Multiple symptoms detected. Consider rest & hydration.
        </p>
      )}

      {history.length > 0 && (
        <div className="history-card">
          <h4>📚 Cycle History</h4>
          <ul>
            {history.map((h, i) => (
              <li key={i}>
                Cycle: {h.cycleLength} days, Period: {h.periodLength} days{" "}
                <span>{h.date.toLocaleDateString()}</span>
              </li>
            ))}
          </ul>
          <p>
            📈 Average Cycle Length:{" "}
            {Math.round(
              history.reduce((a, b) => a + b.cycleLength, 0) / history.length
            ) || cycleLength}
          </p>
        </div>
      )}

      <p className="disclaimer">
        * Predictions are estimates and not medical advice.
      </p>

      {cycleData && (
        <p className="score">
          📊 Cycle Confidence Score: <strong>{getCycleScore()}%</strong>
        </p>
      )}

      {/* LANGUAGE SELECTOR */}
     

      <p className="research">
        📚 Ovulation calculated using standard luteal phase estimation (14 days).
      </p>
    </div>
  );
}
