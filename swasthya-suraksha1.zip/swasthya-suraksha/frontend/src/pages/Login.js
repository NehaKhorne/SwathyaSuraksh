import "./Login.css";
import { useNavigate } from "react-router-dom";

export default function Login() {
  const navigate = useNavigate();

  const handleLogin = () => {
    // temporary navigation (backend later)
    navigate("/dashboard");
  };

  return (
    <div className="login-container">
      <div className="login-card">
        <h1>Swasthya Suraksha</h1>
        <p>Women Health & Safety Platform</p>

        <input type="email" placeholder="Email address" />
        <input type="password" placeholder="Password" />

        <button onClick={handleLogin}>Login</button>

        <span className="footer-text">
          Secure • Private • Reliable
        </span>
      </div>
    </div>
  );
}
