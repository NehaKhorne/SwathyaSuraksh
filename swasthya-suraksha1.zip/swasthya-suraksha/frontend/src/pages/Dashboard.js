import { useState, useRef } from "react";
import { useNavigate } from "react-router-dom";
import "./Dashboard.css";

export default function Dashboard() {
  const navigate = useNavigate();

  const [showSOS, setShowSOS] = useState(false);
  const [loading, setLoading] = useState(false);
  const lastSOSRef = useRef(0);

  const sendSOS = () => {
    if (Date.now() - lastSOSRef.current < 10000) {
      alert("⚠️ Please wait before sending SOS again");
      return;
    }

    if (!navigator.geolocation) {
      alert("❌ Geolocation not supported");
      return;
    }

    setLoading(true);

    navigator.geolocation.getCurrentPosition(
      async (position) => {
        try {
          const { latitude, longitude } = position.coords;

          const contacts =
            JSON.parse(localStorage.getItem("contacts")) || [];

          if (contacts.length === 0) {
            alert("❌ No emergency contacts found");
            setLoading(false);
            return;
          }

          const numbers = contacts.map((c) =>
            c.phone.startsWith("+91") ? c.phone : `+91${c.phone}`
          );

          const res = await fetch(
            "http://localhost:5000/api/sos/send",
            {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                contacts: numbers,
                lat: latitude,
                lng: longitude,
              }),
            }
          );

          const data = await res.json();

          if (!res.ok) {
            throw new Error(data.error || "SOS failed");
          }

          lastSOSRef.current = Date.now();
          alert("🚨 SOS sent successfully");
          setShowSOS(false);
        } catch (err) {
          console.error(err);
          alert("❌ SOS failed");
        } finally {
          setLoading(false);
        }
      },
      () => {
        alert("❌ Location permission denied");
        setLoading(false);
      },
      { enableHighAccuracy: true }
    );
  };

  return (
    <div className="dashboard">
      <header className="dashboard-header">
        <div>
          <h2>Swasthya Suraksha</h2>
          <span>Women Health & Safety Platform</span>
        </div>

        <button className="logout-btn" onClick={() => navigate("/")}>
          Logout
        </button>
      </header>

      <div className="dashboard-grid">
        <div className="card sos-card">
          <h3>🚨 SOS Emergency</h3>
          <p>Instant alert to trusted contacts</p>
          <button
            className="sos-btn"
            onClick={() => setShowSOS(true)}
            disabled={loading}
          >
            SEND SOS
          </button>
        </div>

        <div className="card" onClick={() => navigate("/contacts")}>
          <h3>👥 Emergency Contacts</h3>
          <p>Manage trusted people</p>
        </div>

        <div className="card" onClick={() => navigate("/health")}>
          <h3>💗 Health Status</h3>
          <p>Track basic health info</p>
        </div>

        <div className="card" onClick={() => navigate("/safety")}>
          <h3>⚠️ Safety Tips</h3>
          <p>Daily awareness & alerts</p>
        </div>
      </div>

      {showSOS && (
        <div className="modal-overlay">
          <div className="modal">
            <h3>Confirm SOS</h3>
            <p>Your live location will be shared.</p>

            <div className="modal-actions">
              <button onClick={sendSOS} disabled={loading}>
                {loading ? "Sending..." : "Confirm SOS"}
              </button>
              <button
                className="cancel"
                onClick={() => setShowSOS(false)}
                disabled={loading}
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
