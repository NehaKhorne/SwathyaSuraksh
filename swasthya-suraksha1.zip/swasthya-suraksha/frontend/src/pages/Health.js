import { Link, useNavigate } from "react-router-dom";
import "./Health.css";

export default function Health() {
  const navigate = useNavigate();

  return (
    <div className="health-wrapper">

      {/* 🔙 Back Button */}
      <button className="back-btn" onClick={() => navigate("/dashboard")}>
        ← Back to Dashboard
      </button>

      <div className="health-header">
        <h1>Women’s Health</h1>
        <p>Your personal health companion</p>
      </div>

      <div className="health-grid">
        <Link to="/health/pcos" className="health-card">
          <div className="icon">🧬</div>
          <h3>PCOS Predictor</h3>
          <p>Understand PCOS risk based on symptoms</p>
        </Link>

        <Link to="/health/period-tracker" className="health-card">
          <div className="icon">🩸</div>
          <h3>Period Tracker</h3>
          <p>Track cycles & predict next period</p>
        </Link>

        <Link to="/health/products" className="health-card">
          <div className="icon">🛍️</div>
          <h3>Product Comparison</h3>
          <p>Compare pads, tampons & cups</p>
        </Link>

        <Link to="/health/education" className="health-card">
          <div className="icon">📚</div>
          <h3>Education Hub</h3>
          <p>Blogs & videos on women’s health</p>
        </Link>
      </div>
    </div>
  );
}
