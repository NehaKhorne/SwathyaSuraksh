export const products = [
  {
    id: 1,
    name: "Whisper Ultra Soft XL",
    brand: "Whisper",
    category: "pads",
    highlights: ["High absorbency", "Soft cover", "Widely available"],
    sentiment: {
      positive: 72,
      neutral: 18,
      negative: 10,
    },
    tags: ["Comfort", "Strong absorbency"],
    amazon:
      "https://www.amazon.in/s?k=Whisper+Ultra+Soft+XL",
  },
  {
    id: 2,
    name: "Stayfree Secure Cottony XL",
    brand: "Stayfree",
    category: "pads",
    highlights: ["Cottony soft", "Leak lock", "Budget friendly"],
    sentiment: {
      positive: 68,
      neutral: 22,
      negative: 10,
    },
    tags: ["Budget", "Reliable"],
    amazon:
      "https://www.amazon.in/s?k=Stayfree+Secure+Cottony+XL",
  },
  {
    id: 3,
    name: "Plush Organic Pads",
    brand: "Plush",
    category: "pads",
    highlights: ["100% organic cotton", "No chemicals", "Eco friendly"],
    sentiment: {
      positive: 82,
      neutral: 12,
      negative: 6,
    },
    tags: ["Eco-friendly", "Sensitive skin"],
    amazon:
      "https://www.amazon.in/s?k=Plush+Organic+Pads",
  },
  {
    id: 4,
    name: "Nua Ultra Thin Pads",
    brand: "Nua",
    category: "pads",
    highlights: ["Ultra thin", "Chemical free", "Subscription based"],
    sentiment: {
      positive: 79,
      neutral: 15,
      negative: 6,
    },
    tags: ["Premium", "Comfort"],
    amazon:
      "https://www.amazon.in/s?k=Nua+Sanitary+Pads",
  },
  {
    id: 5,
    name: "Sirona Rash-Free Pads",
    brand: "Sirona",
    category: "pads",
    highlights: ["Herbal core", "Rash protection"],
    sentiment: {
      positive: 74,
      neutral: 18,
      negative: 8,
    },
    tags: ["Sensitive skin"],
    amazon:
      "https://www.amazon.in/s?k=Sirona+Sanitary+Pads",
  },
];
