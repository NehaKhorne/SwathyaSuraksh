module.exports = [
  {
    area: "Andheri East",
    station: "Andheri Police Station",
    contact: "+91-222-684-5678"
  },
  {
    area: "Kurla",
    station: "Kurla Police Station",
    contact: "+91-222-650-1234"
  },
  {
    area: "Dadar",
    station: "Dadar Police Station",
    contact: "+91-222-430-1122"
  }
];
