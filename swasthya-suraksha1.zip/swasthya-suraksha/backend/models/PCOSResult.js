const mongoose = require("mongoose");

const PCOSResultSchema = new mongoose.Schema(
  {
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true
    },
    score: Number,
    riskLevel: String,
    answers: Object
  },
  { timestamps: true }
);

module.exports = mongoose.model("PCOSResult", PCOSResultSchema);
