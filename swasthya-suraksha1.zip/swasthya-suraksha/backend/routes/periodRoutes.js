const express = require("express");
const router = express.Router();
const {
  addPeriod,
  getPeriods
} = require("../controllers/periodController");

router.post("/add", addPeriod);
router.get("/history/:userId", getPeriods);

module.exports = router;